async function send() {
  const files = document.getElementById("files").files;
  const form = new FormData();

  for (let f of files) {
    form.append("files", f);
  }

  document.getElementById("status").innerText = "Procesando...";

  const res = await fetch("https://TU_BACKEND_URL/process", {
    method: "POST",
    body: form
  });

  const blob = await res.blob();
  const url = window.URL.createObjectURL(blob);

  const a = document.createElement("a");
  a.href = url;
  a.download = "gastos.xlsx";
  a.click();

  document.getElementById("status").innerText = "Listo";
}
