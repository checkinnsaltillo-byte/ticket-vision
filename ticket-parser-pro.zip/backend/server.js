const express = require("express");
const multer = require("multer");
const vision = require("@google-cloud/vision");
const XLSX = require("xlsx");
const fs = require("fs");

const parseTicket = require("./parser");
const classify = require("./classifier");

const app = express();
const upload = multer({ dest: "uploads/" });
const client = new vision.ImageAnnotatorClient();

app.get("/", (req, res) => res.send("Ticket Parser PRO activo"));

app.post("/process", upload.array("files"), async (req, res) => {
  try {
    let allRows = [];

    for (const file of req.files) {
      const [result] = await client.textDetection(file.path);
      const text = result.textAnnotations[0]?.description || "";

      const parsed = parseTicket(text);

      parsed.items.forEach(item => {
        allRows.push({
          tienda: parsed.store,
          producto: item.producto,
          categoria: classify(item.producto),
          cantidad: item.cantidad,
          importe: item.importe,
          total_ticket: parsed.total
        });
      });

      fs.unlinkSync(file.path);
    }

    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(allRows);
    XLSX.utils.book_append_sheet(wb, ws, "Gastos");

    const buffer = XLSX.write(wb, { type: "buffer", bookType: "xlsx" });

    res.setHeader("Content-Disposition", "attachment; filename=gastos.xlsx");
    res.send(buffer);

  } catch (err) {
    console.error(err);
    res.status(500).send("Error procesando tickets");
  }
});

app.listen(8080, () => console.log("Running on 8080"));
