function classify(producto) {
  const p = producto.toLowerCase();

  if (p.includes("fregadero") || p.includes("mezcladora")) return "Mantenimiento";
  if (p.includes("led") || p.includes("lámpara")) return "Equipamiento";
  if (p.includes("cinta")) return "Operación";

  return "Otros";
}

module.exports = classify;
