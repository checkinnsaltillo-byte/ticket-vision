function detectStore(text) {
  if (text.includes("VEMEX")) return "VEMEX";
  if (text.toUpperCase().includes("HOME DEPOT")) return "HOME DEPOT";
  return "OTRO";
}

function parseGeneric(lines) {
  let items = [];
  lines.forEach(line => {
    const match = line.match(/(.+?)\s+\$?([\d,]+\.\d{2})/);
    if (match) {
      items.push({
        producto: match[1],
        cantidad: 1,
        importe: parseFloat(match[2].replace(",", ""))
      });
    }
  });
  return items;
}

function parseTicket(text) {
  const lines = text.split("\n").map(l => l.trim()).filter(Boolean);
  const store = detectStore(text);
  const items = parseGeneric(lines);

  const totalMatch = text.match(/TOTAL.*?(\d[\d,]*\.\d{2})/i);

  return {
    store,
    items,
    total: totalMatch ? parseFloat(totalMatch[1].replace(",", "")) : 0
  };
}

module.exports = parseTicket;
